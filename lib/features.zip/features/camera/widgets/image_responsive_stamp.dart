import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../shared/widgets/widgets.dart';
import 'stamp_layout_metrics.dart';

/// Responsive stamp burned into the captured image.
///
/// Uses the same proportional renderer as the live camera. The complete stamp
/// scales as one unit for 1:1, 4:3, 16:9 and Full images on phones/tablets.
class ImageResponsiveStamp extends StatelessWidget {
  const ImageResponsiveStamp({
    super.key,
    required this.data,
    required this.imageSize,
    this.templateIndex = 0,
    this.bottomInset = 0,
  });

  final GpsStampData data;
  final Size imageSize;
  final int templateIndex;
  final double bottomInset;

  @override
  Widget build(BuildContext context) {
    if (imageSize.width <= 0 || imageSize.height <= 0) {
      return const SizedBox.shrink();
    }

    final landscape = imageSize.width > imageSize.height;
    // Keep exactly 5% free space on both sides of the image. This makes every
    // template use 90% of the image width, including portrait 1:1 captures.
    final horizontalGap =
        StampLayoutMetrics.horizontalInset(imageSize.width);
    final stampWidth = imageSize.width - (horizontalGap * 2);
    final bottomGap =
        (imageSize.height * 0.025).clamp(4.0, 12.0).toDouble();

    final desiredHeight = landscape
        ? math.min(stampWidth * 0.16, imageSize.height * 0.24)
        : StampLayoutMetrics.portraitStampHeight(imageSize);
    final availableHeight = math.max(
      1.0,
      imageSize.height - bottomGap - bottomInset,
    );
    final minimumHeight =
        math.min(landscape ? 46.0 : desiredHeight, availableHeight);
    final stampHeight = desiredHeight
        .clamp(minimumHeight, availableHeight)
        .toDouble();

    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned(
          left: horizontalGap,
          right: horizontalGap,
          bottom: bottomGap + bottomInset,
          height: stampHeight,
          child: FittedBox(
            fit: landscape ? BoxFit.contain : BoxFit.fill,
            alignment: Alignment.bottomCenter,
            child: SizedBox(
              width: landscape ? 520 : 360,
              child: GpsStampTemplateOverlay(
                data: data,
                templateIndex: templateIndex,
                compact: true,
                mapSize: landscape ? 52 : 54,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
